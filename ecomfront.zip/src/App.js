import React from "react";
import logo from "./logo.svg";
import "./App.css";
// import Header from "./components/Header";
// import Home from "./pages/home/Home";
// import Footer from "./components/Footer";
// import Checkout from "./pages/checkout/Checkout";
// import ProductDetails from "./pages/product_details/ProductDetails";

function App() {
  return (
    <div className="App">
      {/* <Header />
      <Home />
      <Footer /> */}
      {/* <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header> */}
    </div>
  );
}

export default App;
